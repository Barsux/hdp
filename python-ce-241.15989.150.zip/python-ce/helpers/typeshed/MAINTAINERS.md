At present the active maintainers are (alphabetically):

* Rebecca Chen (@rchen152)
* Jukka Lehtosalo (@JukkaL)
* Ivan Levkivskyi (@ilevkivskyi)
* Sebastian Rittau (@srittau)
* Guido van Rossum (@gvanrossum)
* Shantanu (@hauntsaninja)
* Nikita Sobolev (@sobolevn)
* Aku Viljanen (@Akuli)
* Alex Waygood (@AlexWaygood)
* Jelle Zijlstra (@JelleZijlstra)

Former maintainers include:

* David Fisher (@ddfisher)
* Matthias Kramm (@matthiaskramm)
* Łukasz Langa (@ambv)
* Greg Price (@gnprice)
* Rune Tynan (@CraftSpider)

For security reasons, maintainers who haven't been active for twelve months
(no PR reviews or merges, no opened PRs, no significant participation in
issues or on typing-sig) will have their access rights removed. They will
also be moved to the "former maintainers" section here.

Former maintainers who want their access rights restored should open
an issue or mail one of the active maintainers.
